# 🔥 KAPIL SPAM BOT 🔥

[![Telegram Channel](https://img.shields.io/badge/📢%20Update%20Channel-KomalBotsNetwork-blue?style=flat&logo=telegram)](https://t.me/KomalBotsNetwork)  
[![Support Group](https://img.shields.io/badge/💬%20Support%20Group-KomalMusicRobotSupport-green?style=flat&logo=telegram)](https://t.me/KomalMusicRobotSupport)

<p align="center">
  <img src="https://files.catbox.moe/lg4old.jpg" alt="Kapil Spam Bot Banner" width="500px">
</p>

> 🚀 A powerful **Telethon-based Spam Bot** with multi-user control  
> 💖 Built with love by **Kapil Yadav**

---

## ✨ Features

- 👥 Multi-user support  
- 🛡️ Smart sudo system  
- ⚡ Blazing fast performance  
- 🤖 Telethon-powered  
- 😎 User-friendly interface

---

## 🚀 Deployment

### ☁️ Heroku Deployment

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/RockMusicBot/RockSpam.git)

---

### 💻 VPS Deployment Guide

#### 🔧 Prerequisites

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install python3 python3-pip git screen -y
