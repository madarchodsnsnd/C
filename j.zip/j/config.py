import logging
from telethon import TelegramClient
from os import getenv
from dotenv import load_dotenv
from KapilYadav.data import ALTRON

# Load environment variables from .env file
load_dotenv()

logging.basicConfig(
    format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s',
    level=logging.WARNING
)

# VALUES REQUIRED FOR XBOTS
API_ID = int(getenv("API_ID"))
API_HASH = getenv("API_HASH")

CMD_HNDLR = getenv("CMD_HNDLR", default=".")
hl = CMD_HNDLR  # This fixes the import issue in bot.py

# Bot Tokens
BOT_TOKEN = getenv("BOT_TOKEN")
BOT_TOKEN2 = getenv("BOT_TOKEN2")
BOT_TOKEN3 = getenv("BOT_TOKEN3")
BOT_TOKEN4 = getenv("BOT_TOKEN4")
BOT_TOKEN5 = getenv("BOT_TOKEN5")
BOT_TOKEN6 = getenv("BOT_TOKEN6")
BOT_TOKEN7 = getenv("BOT_TOKEN7")
BOT_TOKEN8 = getenv("BOT_TOKEN8")
BOT_TOKEN9 = getenv("BOT_TOKEN9")
BOT_TOKEN10 = getenv("BOT_TOKEN10")
BOT_TOKEN11 = getenv("BOT_TOKEN11")
BOT_TOKEN12 = getenv("BOT_TOKEN12")
BOT_TOKEN13 = getenv("BOT_TOKEN13")
BOT_TOKEN14 = getenv("BOT_TOKEN14")
BOT_TOKEN15 = getenv("BOT_TOKEN15")
BOT_TOKEN16 = getenv("BOT_TOKEN16")
BOT_TOKEN17 = getenv("BOT_TOKEN17")
BOT_TOKEN18 = getenv("BOT_TOKEN18")
BOT_TOKEN19 = getenv("BOT_TOKEN19")
BOT_TOKEN20 = getenv("BOT_TOKEN20")

SUDO_USERS = list(map(int, getenv("SUDO_USERS", default="7086729173").split()))
for x in ALTRON:
    SUDO_USERS.append(x)

OWNER_ID = int(getenv("OWNER_ID", default="7922553903"))
SUDO_USERS.append(OWNER_ID)

# ------------- CLIENTS -------------
X1 = TelegramClient('X1', API_ID, API_HASH).start(bot_token=BOT_TOKEN)
X2 = TelegramClient('X2', API_ID, API_HASH).start(bot_token=BOT_TOKEN2)
X3 = TelegramClient('X3', API_ID, API_HASH).start(bot_token=BOT_TOKEN3)
X4 = TelegramClient('X4', API_ID, API_HASH).start(bot_token=BOT_TOKEN4)
X5 = TelegramClient('X5', API_ID, API_HASH).start(bot_token=BOT_TOKEN5)
X6 = TelegramClient('X6', API_ID, API_HASH).start(bot_token=BOT_TOKEN6)
X7 = TelegramClient('X7', API_ID, API_HASH).start(bot_token=BOT_TOKEN7)
X8 = TelegramClient('X8', API_ID, API_HASH).start(bot_token=BOT_TOKEN8)
X9 = TelegramClient('X9', API_ID, API_HASH).start(bot_token=BOT_TOKEN9)
X10 = TelegramClient('X10', API_ID, API_HASH).start(bot_token=BOT_TOKEN10)
X11 = TelegramClient('X11', API_ID, API_HASH).start(bot_token=BOT_TOKEN11)
X12 = TelegramClient('X12', API_ID, API_HASH).start(bot_token=BOT_TOKEN12)
X13 = TelegramClient('X13', API_ID, API_HASH).start(bot_token=BOT_TOKEN13)
X14 = TelegramClient('X14', API_ID, API_HASH).start(bot_token=BOT_TOKEN14)
X15 = TelegramClient('X15', API_ID, API_HASH).start(bot_token=BOT_TOKEN15)
X16 = TelegramClient('X16', API_ID, API_HASH).start(bot_token=BOT_TOKEN16)
X17 = TelegramClient('X17', API_ID, API_HASH).start(bot_token=BOT_TOKEN17)
X18 = TelegramClient('X18', API_ID, API_HASH).start(bot_token=BOT_TOKEN18)
X19 = TelegramClient('X19', API_ID, API_HASH).start(bot_token=BOT_TOKEN19)
X20 = TelegramClient('X20', API_ID, API_HASH).start(bot_token=BOT_TOKEN20)
