from telethon import events, Button, __version__  # Import __version__ directly
from config import X1, X2, X3, X4, X5, X6, X7, X8, X9, X10, X11, X12, X13, X14, X15, X16, X17, X18, X19, X20

START_BUTTON = [
    [
        Button.inline("• ᴄᴏᴍᴍᴀɴᴅs •", data="help_back")
    ],
    [
        Button.url("• ᴄʜᴀɴɴᴇʟ •", "https://t.me/WarzoneEsports"),
        Button.url("• sᴜᴘᴘᴏʀᴛ •", "https://t.me/Warzone_SquadZone")
    ],
    [
        Button.url("• ʀᴇᴘᴏ •", "https://files.catbox.moe/am0g64.mp4")
    ]
]

@X1.on(events.NewMessage(pattern="/start"))
@X2.on(events.NewMessage(pattern="/start"))
@X3.on(events.NewMessage(pattern="/start"))
@X4.on(events.NewMessage(pattern="/start"))
@X5.on(events.NewMessage(pattern="/start"))
@X6.on(events.NewMessage(pattern="/start"))
@X7.on(events.NewMessage(pattern="/start"))
@X8.on(events.NewMessage(pattern="/start"))
@X9.on(events.NewMessage(pattern="/start"))
@X10.on(events.NewMessage(pattern="/start"))
@X11.on(events.NewMessage(pattern="/start"))
@X12.on(events.NewMessage(pattern="/start"))
@X13.on(events.NewMessage(pattern="/start"))
@X14.on(events.NewMessage(pattern="/start"))
@X15.on(events.NewMessage(pattern="/start"))
@X16.on(events.NewMessage(pattern="/start"))
@X17.on(events.NewMessage(pattern="/start"))
@X18.on(events.NewMessage(pattern="/start"))
@X19.on(events.NewMessage(pattern="/start"))
@X20.on(events.NewMessage(pattern="/start"))
async def start(event):              
    if event.is_private:
        AltBot = await event.client.get_me()
        bot_name = AltBot.first_name
        bot_id = AltBot.id
        TEXT = f"ʜᴇʏ [{event.sender.first_name}](tg://user?id={event.sender.id}),\n\nɪ ᴀᴍ [{bot_name}](tg://user?id={bot_id})\n━━━━━━━━━━━━━━━━━━━\n\n"
        TEXT += f"» ᴍʏ ᴅᴇᴠᴇʟᴏᴘᴇʀ : [RAJA BHAI](https://t.me/RAJARAJ909)\n\n"
        TEXT += f"» chut  ᴠᴇʀsɪᴏɴ : M3.3\n"
        TEXT += f"» �ᴘʏᴛʜᴏɴ ᴠᴇʀsɪᴏɴ : elvish ki mummy ki chudai\n"
        TEXT += f"» ᴛᴇʟᴇᴛʜᴏɴ ᴠᴇʀsɪᴏɴ : {__version__}\n━━━━━━━━━━━━━━━━━"
        await event.client.send_file(
            event.chat_id,
            "https://files.catbox.moe/vftg0l.jpg",
            caption=TEXT, 
            buttons=START_BUTTON
        )
